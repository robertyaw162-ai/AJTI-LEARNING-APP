AJTI LEARNING APP V7.8 — SIX DEPARTMENTS

Included:
- Six AJTI departments
- Year 1, Year 2, Year 3 selection
- Six shared subjects: English Language, Mathematics, Integrated Science, ICT, Social Studies, Entrepreneurship
- Starter study guides for the shared subjects
- Existing offline-first Kivy prototype features from V7.7

IMPORTANT:
The department subject sequence in this prototype is provisional, not a verified official AJTI scheme of learning. Please compare it with the school's current scheme before treating it as official. The source file passed Python syntax compilation, but this environment did not launch the app in an Android/Kivy runtime.

For the existing GitHub/Buildozer workflow, use main.py as the app source file.
