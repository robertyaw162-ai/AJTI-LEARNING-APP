[app]

title = AJTI Learning App
package.name = ajtilearning
package.domain = org.ajti
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt,json
version = 6.0

requirements = python3,kivy
orientation = portrait
fullscreen = 0

# Provisional app branding. Replace with the official AJTI logo when available.
# icon.filename = %(source.dir)s/ajti_icon.png

android.permissions =
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
